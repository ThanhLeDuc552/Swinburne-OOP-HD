using swin_adventure;

namespace TestIdentifiableObject
{
    public class UnitTest1
    {
        IdentifiableObject obj = new IdentifiableObject(new string[] { "105548505", "Le Duc Thanh", "Le" });

        [Fact]
        public void TestAreYou()
        {
            Assert.True(obj.AreYou("105548505"));
        }

        [Fact]
        public void TestNotAreYou()
        {
            Assert.False(obj.AreYou("1o5548505"));
        }

        [Fact]
        public void TestCaseSentitive()
        {
            Assert.True(obj.AreYou("LE"));
        }

        [Fact]
        public void TestFirstId()
        {
            Assert.Equal("105548505", obj.FirstId);
            IdentifiableObject obj2 = new IdentifiableObject(new string[] {});
            Assert.Equal(obj2.FirstId, "");
        }

        [Fact]
        public void TestAddId()
        {
            obj.AddIdentifier("Duong");
            Assert.Contains("duong", obj._identifiers);
        }

        [Fact]
        public void TestPrivilegeEscalation()
        {
            obj.PrivilegeEscalation("8505");
            Assert.Equal("105548505", obj.FirstId);
        }
    }
}